For p1_fifo.c:		//which generates the random array and send it to p2_fifo.c, which gives back the max. index to p1_fifo.c

--> Generating array of randomly generated string using string_generator().

-->Generating pathway fileA, fileB to access array between p1 and p2 using FIFO subroutine.

-->Then, printing the array generated and then sending 5 strings to p2 using write() and open().

-->Now, reading the index sent by p2 using read().


For p2_fifo.c:		//which recieves the random generated array from p1_fifo.c and returns max. index to p1_fifo.c

-->It also creates pathway in the similiar manner.

-->Then, reads the string using read() and returns the max index using write().



